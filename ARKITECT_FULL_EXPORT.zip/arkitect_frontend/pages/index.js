export default function Home() {
  return <div>ARKITECT Frontend ativo</div>;
}