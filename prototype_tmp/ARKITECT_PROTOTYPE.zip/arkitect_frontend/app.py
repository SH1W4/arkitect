# Streamlit interface principal

import streamlit as st

st.set_page_config(page_title='ARKITECT', layout='wide')
st.title('ARKITECT - Inteligência de Documentação de Projetos')
st.info('Faça upload do seu projeto para começar.')