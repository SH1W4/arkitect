# ARKITECT

🚀 Inteligência simbiótica para documentação automatizada de projetos.