# Fluxo da Interface

Descrição do comportamento e navegação em Streamlit.