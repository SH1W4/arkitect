# API (Backend)

Endpoints, parâmetros e exemplos de uso.